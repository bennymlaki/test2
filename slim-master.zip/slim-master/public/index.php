<?php
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PATCH, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Origin, Content-Type, X-Auth-Token');
require '../vendor/autoload.php';
// Create and configure Slim app
$config = ['settings' => [
    'addContentLengthHeader' => false,
    'db'=> [
        'host'=> 'localhost',
        'user'=> 'root',
        'pass'=> '',
        'db'=> 'ue'
    ],
]];
$app = new \Slim\App($config);
require 'dependencies.php';

// Define app routes
$app->get('/hello', function ($request, $response, $args) {

    $sql = 'SELECT * FROM tbl_user1';
    $stmt = $this->db->prepare($sql);

    $stmt->execute();
    $row = $stmt->fetchAll();

    return $response->withJson($row);
});

$app->post('/login', function ($request, $response, $args){

    $array = $request->getParsedBody();
    $username=$array['username'];
    $password=md5($array['password']);

    $sql = "SELECT * FROM tbl_user1 WHERE username='$username' AND password='$password'";
    $stmp = $this->db->prepare($sql);
    $stmp->execute();
    $result = array();
    if ($stmp->rowCount()>0){
        $row = $stmp->fetch();
        $result['status']=200;
        $result['data']= array(
            "id"=>$row['id'],
            "username"=>$row['username'],
            "password"=>$row['password'],
            "full_name"=>$row['full_name'],
            "message"=>"request was successfuly"
        );

        return $response->withJson($result);
    }else{
        $result['status']=400;
        $result['data']=[
            "id"=>'0',
            "username"=>'',
            "password"=>'',
            "message"=>'user not found'
        ];

        return $response->withJson($result);
    }

});

$app->post('/register', function ($request, $response, $args){

    $array = $request->getParsedBody();
    $full_name=$array['full_name'];
    $username=$array['username'];
    $password=md5($array['password']);

    $sql = "INSERT INTO `tbl_user1`( `full_name`, `username`, `password`) VALUES (?,?,?)";

    $stmt = $this->db->prepare($sql);
    $result =$stmt->execute([$full_name,$username,$password]);


    if ($result){
        return $response->withJson(["status" => 200]);
    }else{
        return $response->withJson(["status" => 400]);
    }

});

$app->get('/r3', function ($request, $response, $args){

    $sql = "SELECT * FROM tbl_project";
    $stmp = $this->db->prepare($sql);
    $stmp->execute();
    $result = array();
    if ($stmp->rowCount()>0){
        $row = $stmp->fetchAll();
        $result['status']=200;
        $result['data']= $row;

        return $response->withJson($result);
    }else{
        $result['status']=400;
        $result['data']=[
            "id"=>'0',
            "name"=>'',
            "description"=>'',
            "message"=>'user not found'
        ];

        return $response->withJson($result);
    }

});


$app->post('/r4', function ($request, $response, $args){

    $array = $request->getParsedBody();
    $name=$array['name'];
    $description=$array['description'];
    $amount=$array['amount'];

    $sql = "INSERT INTO `tbl_project`( `name`, `description`, `amount`) VALUES (?,?,?)";

    $stmt = $this->db->prepare($sql);
    $result =$stmt->execute([$name, $description,$amount]);


    if ($result){
        return $response->withJson(["status" => 200]);
    }else{
        return $response->withJson(["status" => 400]);
    }

});


$app->get('/r5', function ($request, $response, $args){

    $sql = "SELECT COUNT(name) AS total FROM tbl_project";
    $stmp = $this->db->prepare($sql);
    $stmp->execute();
    $result = array();
    if ($stmp->rowCount()>0){
        $row = $stmp->fetchAll();
        $result['status']=200;
        $result['data']= $row;

        return $response->withJson($result);
    }else{
        $result['status']=400;
        $result['data']=[
            "id"=>'0',
            "name"=>'',
            "description"=>'',
            "message"=>'user not found'
        ];

        return $response->withJson($result);
    }

});

$app->post('/r6', function ($request, $response, $args){

    $array = $request->getParsedBody();
    $id=$array['id'];
    $name=$array['name'];
    $description=$array['description'];
    $amount=$array['amount'];

    $sql = "UPDATE `tbl_project` SET `name`=?,`description`=?,`amount`=? WHERE `id`=? ";

    $stmt = $this->db->prepare($sql);
    $result =$stmt->execute([$name, $description, $amount, $id]);


    if ($result){
        return $response->withJson(["status" => 200]);
    }else{
        return $response->withJson(["status" => 400]);
    }

});

$app->post('/r7', function ($request, $response, $args){

    $array = $request->getParsedBody();
    $id=$array['id'];


    $sql = "DELETE FROM `tbl_project` WHERE `id`='$id'";


    $stmt = $this->db->prepare($sql);
    $result =$stmt->execute();


    if ($result){
        return $response->withJson(["status" => 200]);
    }else{
        return $response->withJson(["status" => 400]);
    }

});

$app->post('/r8', function ($request, $response, $args){

    $array = $request->getParsedBody();
    $id=$array['id'];

    $sql = "SELECT * FROM tbl_project WHERE id='$id'";
    $stmp = $this->db->prepare($sql);
    $stmp->execute();
    $result = array();
    if ($stmp->rowCount()>0){
        $row = $stmp->fetch();
        $result['status']=200;
        $result['data']= $row;

        return $response->withJson($result);
    }else{
        $result['status']=400;
        $result['data']=[
            "message"=>'user not found'
        ];

        return $response->withJson($result);
    }

});

// Run app
$app->run();