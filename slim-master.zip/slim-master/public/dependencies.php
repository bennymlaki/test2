<?php
$container = $app->getContainer();
$container['db'] = function ($c) {

    $settings = $c->get('settings')['db'];
    $pdo = new PDO("mysql:host={$settings['host']};dbname={$settings['db']}",
        "{$settings['user']}", "{$settings['pass']}");
    return $pdo;
};