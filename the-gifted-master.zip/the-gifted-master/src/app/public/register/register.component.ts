import { Component, OnInit } from '@angular/core';
import {FormBuilder, FormGroup, Validators} from '@angular/forms';
import {Router} from '@angular/router';
import {UserService} from '../../services/user.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
    private formGroup: FormGroup;
  constructor(
      private user: UserService,
      private fbuilder: FormBuilder,
      private route: Router
  ) { }

  ngOnInit() {
    this.initializeForm();
  }
    initializeForm() {
        this.formGroup = this.fbuilder.group({
            full_name: ['', [Validators.required]],
            username: ['', [Validators.required]],
            password: ['', [Validators.required]],
        });
    }
    onSubmitForm(formData: any) {
        console.log(formData);
        this.user.register(formData).subscribe((res1: any) => {
            console.log(res1);
            if (res1['status'] === 200) {
                this.route.navigate(['/login']);
            }
        }, error2 => {
            console.log(error2);
        });
    }

}
