import { Component, OnInit } from '@angular/core';
import {UserService} from '../../services/user.service';
import {FormBuilder, FormGroup, Validators} from '@angular/forms';
import {Router} from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

    private formGroup: FormGroup;
  constructor(private user: UserService,
              private fbuilder: FormBuilder,
              private route: Router
              ) { }

  ngOnInit() {
      this.initializeForm();
  }
    initializeForm() {
      this.formGroup = this.fbuilder.group({
          username: ['', [Validators.required]],
          password: ['', [Validators.required]],
      });
    }

    onSubmitForm(formData: any) {
        console.log(formData);
      this.user.login(formData).subscribe((res1: any) => {
          console.log(res1);
          if (res1['status'] === 200) {
             this.route.navigate(['/dashboard']);
          }
      }, error2 => {
          console.log(error2);
      });
    }

}
