import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class UserService {
  private url = 'http://localhost/final/slime/public/hello';
  private url_login = 'http://localhost/final/slime/public/login';
  private url_register = 'http://localhost/final/slime/public/register';
  constructor(private http: HttpClient) { }
  getInfo() {
    return this.http.get(this.url);
  }
    login(fdata: any) {
      return this.http.post(this.url_login, fdata);
    }
    register(fdata: any) {
      return this.http.post(this.url_register, fdata);
    }
}
